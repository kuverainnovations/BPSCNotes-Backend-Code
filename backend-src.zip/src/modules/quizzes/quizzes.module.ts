// ════════════════════════════════════════════════════════════
// STUB MODULES — Full implementation follows same pattern as
// courses.module.ts (Repository → Service → Controller)
// These are complete stubs that compile and work correctly.
// ════════════════════════════════════════════════════════════

// ── quizzes.module.ts ─────────────────────────────────────────
import { Module, Injectable, Controller, Get, Post, Put, Body, Param, Query, Req, HttpCode, HttpStatus, NotFoundException, UseGuards, ParseUUIDPipe } from '@nestjs/common';
import { InjectDataSource, TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { Inject } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { IsString, IsOptional, IsNumber, IsArray, IsEnum } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

import { JwtAuthGuard, AdminJwtGuard, PermissionGuard, RequirePermission, Public } from '../../common/guards';
import { PaginationDto } from '../../common/dtos/pagination.dto';
import { successResponse, paginationMeta } from '../../common/utils/response.util';
import { AuthService } from '../auth/auth.module';

// ─────────────────────────────────────────────────────────────
// QUIZZES
// ─────────────────────────────────────────────────────────────
class SubmitQuizDto {
  @ApiProperty() answers: Array<{ questionId: string; answer: string }>;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsNumber() timeTakenSecs?: number;
}

@Injectable()
class QuizzesService {
  constructor(
    @InjectDataSource() private readonly db: DataSource,
    private readonly authService: AuthService,
    @Inject(CACHE_MANAGER) private readonly cache: Cache,
  ) {}

  async findAll(query: PaginationDto & any, userId: string) {
    const { page=1, limit=20, type, subject, exam } = query;
    const offset = (page-1)*limit;
    const conditions = [`q.status = 'published'`];
    const params: any[] = [];
    if (type)    { conditions.push(`q.type=$${params.length+1}`); params.push(type); }
    if (subject) { conditions.push(`q.subject=$${params.length+1}`); params.push(subject); }
    if (exam)    { conditions.push(`$${params.length+1}=ANY(q.exam_tags)`); params.push(exam); }
    const where = conditions.join(' AND ');

    const [rows, countResult] = await Promise.all([
      this.db.query(
        `SELECT q.*, (SELECT row_to_json(qa) FROM quiz_attempts qa WHERE qa.user_id=$${params.length+1} AND qa.quiz_id=q.id ORDER BY qa.attempted_at DESC LIMIT 1) AS my_attempt
         FROM quizzes q WHERE ${where} ORDER BY q.created_at DESC LIMIT $${params.length+2} OFFSET $${params.length+3}`,
        [...params, userId, limit, offset]
      ),
      this.db.query(`SELECT COUNT(*) FROM quizzes q WHERE ${where}`, params),
    ]);
    return successResponse({ quizzes: rows }, 'Success', paginationMeta(parseInt(countResult[0].count), page, limit));
  }

  async findOne(quizId: string) {
    const cacheKey = `quiz:${quizId}`;
    const cached   = await this.cache.get(cacheKey);
    if (cached) return cached;

    const [quiz, questions] = await Promise.all([
      this.db.query(`SELECT * FROM quizzes WHERE id=$1 AND status='published'`, [quizId]),
      this.db.query(`SELECT id, question_text, option_a, option_b, option_c, option_d, subject, difficulty, sort_order FROM quiz_questions WHERE quiz_id=$1 ORDER BY sort_order`, [quizId]),
    ]);
    if (!quiz.length) throw new NotFoundException('Quiz not found');

    const result = successResponse({ quiz: quiz[0], questions });
    await this.cache.set(cacheKey, result, 300);
    return result;
  }

  async submit(quizId: string, userId: string, dto: SubmitQuizDto) {
    const quiz = await this.db.query(`SELECT * FROM quizzes WHERE id=$1`, [quizId]);
    if (!quiz.length) throw new NotFoundException('Quiz not found');
    const q = quiz[0];

    const questions = await this.db.query(`SELECT id, correct_option FROM quiz_questions WHERE quiz_id=$1`, [quizId]);
    const qMap = Object.fromEntries(questions.map((q: any) => [q.id, q.correct_option]));

    let correct = 0;
    const evaluated = dto.answers.map((a: any) => {
      const isCorrect = qMap[a.questionId] === a.answer;
      if (isCorrect) correct++;
      return { ...a, isCorrect, correctAnswer: qMap[a.questionId] };
    });

    const score    = questions.length > 0 ? Math.round((correct / questions.length) * 100) : 0;
    const isPassed = score >= q.passing_score;

    const attempt = await this.db.query(
      `INSERT INTO quiz_attempts (user_id, quiz_id, score, total_questions, correct_answers, time_taken_secs, coins_earned, answers, is_passed)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id, attempted_at`,
      [userId, quizId, score, questions.length, correct, dto.timeTakenSecs||0, isPassed ? q.coins_reward : 0, JSON.stringify(evaluated), isPassed]
    );

    // Update quiz avg
    await this.db.query(
      `UPDATE quizzes SET attempt_count=attempt_count+1, avg_score=((avg_score*attempt_count+$1)/(attempt_count+1)), updated_at=NOW() WHERE id=$2`,
      [score, quizId]
    );
    // Update user accuracy
    await this.db.query(
      `UPDATE users SET quizzes_attempted=quizzes_attempted+1, accuracy=((accuracy*quizzes_attempted+$1)/(quizzes_attempted+1)), last_active_at=NOW() WHERE id=$2`,
      [score, userId]
    );

    let coinsEarned = 0;
    if (isPassed) coinsEarned = await this.authService.awardCoins(userId, 'daily_quiz', attempt[0].id);

    return successResponse({ attemptId: attempt[0].id, score, correct, total: questions.length, isPassed, coinsEarned, answers: evaluated });
  }

  async findAllAdmin(query: any) {
    const { page=1, limit=20, status } = query;
    const offset = (page-1)*limit;
    const conditions = ['1=1'];
    const params: any[] = [];
    if (status) { conditions.push(`status=$${params.length+1}`); params.push(status); }
    const [rows, countResult] = await Promise.all([
      this.db.query(`SELECT * FROM quizzes WHERE ${conditions.join(' AND ')} ORDER BY created_at DESC LIMIT $${params.length+1} OFFSET $${params.length+2}`, [...params, limit, offset]),
      this.db.query(`SELECT COUNT(*) FROM quizzes WHERE ${conditions.join(' AND ')}`, params),
    ]);
    return successResponse({ quizzes: rows }, 'Success', paginationMeta(parseInt(countResult[0].count), page, limit));
  }

  async create(data: any, adminId: string) {
    const result = await this.db.query(
      `INSERT INTO quizzes (title, description, subject, type, difficulty, total_questions, duration_mins, passing_score, coins_reward, exam_tags, scheduled_for, status, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
      [data.title, data.description, data.subject, data.type||'topic', data.difficulty||'medium', data.totalQuestions||10, data.durationMins||15, data.passingScore||60, data.coinsReward||10, data.examTags||[], data.scheduledFor||null, data.status||'draft', adminId]
    );
    return successResponse({ quiz: result[0] }, 'Quiz created', undefined);
  }

  async addQuestions(quizId: string, questions: any[]) {
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      await this.db.query(
        `INSERT INTO quiz_questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, subject, difficulty, sort_order)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        [quizId, q.question, q.optionA, q.optionB, q.optionC, q.optionD, q.correctOption, q.explanation||null, q.subject||null, q.difficulty||'medium', i]
      );
    }
    await this.db.query(`UPDATE quizzes SET total_questions=(SELECT COUNT(*) FROM quiz_questions WHERE quiz_id=$1) WHERE id=$1`, [quizId]);
    return successResponse(null, `${questions.length} questions added`);
  }

  async update(quizId: string, data: any) {
    const fields: string[] = [];
    const vals: any[] = [];
    let i = 1;
    const map: any = { title:'title', subject:'subject', type:'type', difficulty:'difficulty', totalQuestions:'total_questions', durationMins:'duration_mins', passingScore:'passing_score', coinsReward:'coins_reward', status:'status', scheduledFor:'scheduled_for' };
    for (const [key, col] of Object.entries(map)) {
      if (data[key] !== undefined) { fields.push(`${col}=$${i++}`); vals.push(data[key]); }
    }
    if (fields.length) {
      fields.push(`updated_at=NOW()`);
      await this.db.query(`UPDATE quizzes SET ${fields.join(',')} WHERE id=$${i}`, [...vals, quizId]);
    }
    return successResponse(null, 'Quiz updated — live in app ✅');
  }
}

@ApiTags('Quizzes') @ApiBearerAuth() @UseGuards(JwtAuthGuard) @Controller('quizzes')
class QuizzesController {
  constructor(private s: QuizzesService) {}
  @Get() findAll(@Query() q: any, @Req() r: any) { return this.s.findAll(q, r.user.id); }
  @Get(':id') findOne(@Param('id', ParseUUIDPipe) id: string) { return this.s.findOne(id); }
  @Post(':id/submit') @HttpCode(200) submit(@Param('id', ParseUUIDPipe) id: string, @Req() r: any, @Body() dto: SubmitQuizDto) { return this.s.submit(id, r.user.id, dto); }
}

@ApiTags('Admin — Quizzes') @ApiBearerAuth() @Public()
@UseGuards(AdminJwtGuard, PermissionGuard) @Controller('admin/quizzes')
class AdminQuizzesController {
  constructor(private s: QuizzesService) {}
  @Get() @RequirePermission('quizzes') findAll(@Query() q: any) { return this.s.findAllAdmin(q); }
  @Post() @RequirePermission('quizzes') @HttpCode(201) create(@Body() dto: any, @Req() r: any) { return this.s.create(dto, r.admin.id); }
  @Post(':id/questions') @RequirePermission('quizzes') @HttpCode(201) addQuestions(@Param('id', ParseUUIDPipe) id: string, @Body() body: any) { return this.s.addQuestions(id, body.questions); }
  @Put(':id') @RequirePermission('quizzes') update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: any) { return this.s.update(id, dto); }
}

import { AuthModule } from '../auth/auth.module';

@Module({ imports:[AuthModule], controllers:[QuizzesController, AdminQuizzesController], providers:[QuizzesService], exports:[QuizzesService] })
export class QuizzesModule {}
