import {
  Module, Injectable, Controller, Get, Post, Put, Delete,
  Body, Param, Query, Req, HttpCode, HttpStatus,
  NotFoundException, BadRequestException, ForbiddenException,
  UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { Inject } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AuthModule, AuthService } from './auth/auth.module';

import { JwtAuthGuard, AdminJwtGuard, PermissionGuard, RequirePermission, Public } from '../common/guards';
import { PaginationDto } from '../common/dtos/pagination.dto';
import { successResponse, paginationMeta } from '../common/utils/response.util';

// ════════════════════════════════════════════════════════════
// STUDY ROOMS MODULE
// ════════════════════════════════════════════════════════════
@Injectable()
class StudyRoomsService {
  constructor(
    @InjectDataSource() private readonly db: DataSource,
    private readonly authService: AuthService,
  ) {}

  async findAll(query: any, userId: string) {
    const { subject, exam } = query;
    const conditions = [`sr.status='active'`], params: any[] = [];
    if (subject) { conditions.push(`sr.subject=$${params.length+1}`); params.push(subject); }
    if (exam)    { conditions.push(`$${params.length+1}=ANY(sr.exam_tags)`); params.push(exam); }
    const rows = await this.db.query(
      `SELECT sr.*, u.name AS host_name,
         COUNT(rm.user_id) FILTER (WHERE rm.left_at IS NULL) AS current_members,
         (SELECT TRUE FROM room_members WHERE room_id=sr.id AND user_id=$${params.length+1} AND left_at IS NULL) AS is_member
       FROM study_rooms sr JOIN users u ON sr.host_id=u.id
       LEFT JOIN room_members rm ON sr.id=rm.room_id
       WHERE ${conditions.join(' AND ')}
       GROUP BY sr.id, u.name ORDER BY sr.created_at DESC`,
      [...params, userId]
    );
    return successResponse({ rooms: rows });
  }

  async create(data: any, userId: string) {
    if (!data.name || !data.subject) throw new BadRequestException('Name and subject required');
    const joinCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    const result   = await this.db.query(
      `INSERT INTO study_rooms (name, subject, host_id, max_members, is_private, join_code, exam_tags)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [data.name, data.subject, userId, data.maxMembers||20, data.isPrivate||false, joinCode, data.examTags||[]]
    );
    const room = result[0];
    await this.db.query(`INSERT INTO room_members (room_id, user_id) VALUES ($1,$2)`, [room.id, userId]);
    await this.authService.awardCoins(userId, 'study_room', room.id);
    return successResponse({ room }, 'Study room created!');
  }

  async join(roomId: string, userId: string, joinCode?: string) {
    const room = await this.db.query(`SELECT * FROM study_rooms WHERE id=$1 AND status='active'`, [roomId]);
    if (!room.length) throw new NotFoundException('Room not found or ended');
    const r = room[0];
    if (r.is_private && r.join_code !== joinCode) throw new ForbiddenException('Invalid room code');
    const memberCount = await this.db.query(`SELECT COUNT(*) FROM room_members WHERE room_id=$1 AND left_at IS NULL`, [roomId]);
    if (parseInt(memberCount[0].count) >= r.max_members) throw new BadRequestException('Room is full');
    await this.db.query(
      `INSERT INTO room_members (room_id, user_id) VALUES ($1,$2) ON CONFLICT (room_id, user_id) DO UPDATE SET left_at=NULL, joined_at=NOW()`,
      [roomId, userId]
    );
    await this.authService.awardCoins(userId, 'study_room', roomId);
    return successResponse({ room: r }, 'Joined study room!');
  }

  async leave(roomId: string, userId: string) {
    await this.db.query(`UPDATE room_members SET left_at=NOW() WHERE room_id=$1 AND user_id=$2`, [roomId, userId]);
    return successResponse(null, 'Left the room');
  }

  async findAllAdmin() {
    const rows = await this.db.query(
      `SELECT sr.*, u.name AS host_name,
         COUNT(rm.user_id) FILTER (WHERE rm.left_at IS NULL) AS current_members
       FROM study_rooms sr JOIN users u ON sr.host_id=u.id
       LEFT JOIN room_members rm ON sr.id=rm.room_id
       GROUP BY sr.id, u.name ORDER BY sr.created_at DESC`
    );
    return successResponse({ rooms: rows });
  }

  async endRoom(roomId: string) {
    await this.db.query(`UPDATE study_rooms SET status='ended', ended_at=NOW(), updated_at=NOW() WHERE id=$1`, [roomId]);
    return successResponse(null, 'Room ended');
  }
}

@ApiTags('Study Rooms') @ApiBearerAuth() @UseGuards(JwtAuthGuard) @Controller('study-rooms')
class StudyRoomsController {
  constructor(private s: StudyRoomsService) {}
  @Get()      findAll(@Query() q: any, @Req() r: any) { return this.s.findAll(q, r.user.id); }
  @Post()     @HttpCode(201) create(@Body() dto: any, @Req() r: any) { return this.s.create(dto, r.user.id); }
  @Post(':id/join')  @HttpCode(200) join(@Param('id', ParseUUIDPipe) id: string, @Req() r: any, @Body() b: any) { return this.s.join(id, r.user.id, b.joinCode); }
  @Post(':id/leave') @HttpCode(200) leave(@Param('id', ParseUUIDPipe) id: string, @Req() r: any) { return this.s.leave(id, r.user.id); }
}

@ApiTags('Admin — Study Rooms') @ApiBearerAuth() @Public()
@UseGuards(AdminJwtGuard, PermissionGuard) @Controller('admin/study-rooms')
class AdminStudyRoomsController {
  constructor(private s: StudyRoomsService) {}
  @Get()         @RequirePermission('study-rooms') findAll()  { return this.s.findAllAdmin(); }
  @Put(':id/end') @RequirePermission('study-rooms') end(@Param('id', ParseUUIDPipe) id: string) { return this.s.endRoom(id); }
}

@Module({ imports:[AuthModule], controllers:[StudyRoomsController, AdminStudyRoomsController], providers:[StudyRoomsService] })
export class StudyRoomsModule {}

// ════════════════════════════════════════════════════════════
// USERS MODULE  (profile, stats, leaderboard, live classes, certs, downloads)
// ════════════════════════════════════════════════════════════
@Injectable()
class UsersService {
  constructor(
    @InjectDataSource() private readonly db: DataSource,
    @Inject(CACHE_MANAGER) private readonly cache: Cache,
  ) {}

  async getProfile(userId: string) {
    const cacheKey = `profile:${userId}`;
    const cached   = await this.cache.get(cacheKey);
    if (cached) return cached;

    const result = await this.db.query(
      `SELECT u.id,u.name,u.email,u.mobile,u.avatar_url,u.bio,u.district,u.state,
              u.primary_exam,u.secondary_exam,u.prep_level,u.target_year,
              u.streak,u.longest_streak,u.coins,u.total_coins_earned,
              u.total_study_minutes,u.accuracy,u.quizzes_attempted,
              u.rank,u.is_verified,u.referral_code,u.created_at AS joined_date,
              u.notification_enabled,
              (SELECT COUNT(*) FROM user_enrollments WHERE user_id=u.id) AS enrolled_courses,
              (SELECT COUNT(*) FROM certificates WHERE user_id=u.id) AS certificates_count,
              (SELECT COUNT(*) FROM subscriptions WHERE user_id=u.id AND status='active' AND ends_at>NOW())>0 AS is_subscribed,
              (SELECT plan FROM subscriptions WHERE user_id=u.id AND status='active' AND ends_at>NOW() LIMIT 1) AS current_plan
       FROM users u WHERE u.id=$1 AND u.deleted_at IS NULL`,
      [userId]
    );
    if (!result.length) throw new NotFoundException('User not found');
    const data = successResponse({ user: result[0] });
    await this.cache.set(cacheKey, data, 60);
    return data;
  }

  async updateProfile(userId: string, data: any) {
    const fields: string[] = [], vals: any[] = [];
    let i = 1;
    const allowed = ['name','bio','email','district','state'];
    for (const key of allowed) {
      if (data[key] !== undefined) { fields.push(`${key}=$${i++}`); vals.push(data[key]); }
    }
    if (fields.length) { fields.push('updated_at=NOW()'); await this.db.query(`UPDATE users SET ${fields.join(',')} WHERE id=$${i}`, [...vals, userId]); }
    await this.cache.del(`profile:${userId}`);
    await this.cache.del(`user:${userId}`);
    return successResponse(null, 'Profile updated');
  }

  async updateExamTarget(userId: string, data: any) {
    await this.db.query(
      `UPDATE users SET primary_exam=$1, secondary_exam=$2, prep_level=$3, target_year=$4, updated_at=NOW() WHERE id=$5`,
      [data.primaryExam, data.secondaryExam||null, data.prepLevel||'beginner', data.targetYear||null, userId]
    );
    await this.cache.del(`profile:${userId}`);
    await this.cache.del(`user:${userId}`);
    return successResponse(null, 'Exam target updated');
  }

  async getStats(userId: string) {
    const [subjectStats, recentQuizzes, weeklyActivity] = await Promise.all([
      this.db.query(
        `SELECT q.subject, COUNT(*) AS attempts, ROUND(AVG(qa.score::decimal/NULLIF(qa.total_questions,0)*100),1) AS avg_accuracy
         FROM quiz_attempts qa JOIN quizzes q ON qa.quiz_id=q.id WHERE qa.user_id=$1 GROUP BY q.subject`,
        [userId]
      ),
      this.db.query(
        `SELECT qa.score, qa.total_questions, qa.attempted_at, qa.is_passed, q.title, q.type, q.subject
         FROM quiz_attempts qa JOIN quizzes q ON qa.quiz_id=q.id
         WHERE qa.user_id=$1 ORDER BY qa.attempted_at DESC LIMIT 10`,
        [userId]
      ),
      this.db.query(
        `SELECT DATE(qa.attempted_at) AS date, COUNT(*) AS activity
FROM quiz_attempts qa
WHERE qa.user_id=$1 AND qa.attempted_at >= NOW() - INTERVAL '28 days'
GROUP BY DATE(qa.attempted_at)
ORDER BY date ASC`,
        [userId]
      ),
    ]);
    return successResponse({ subjectAccuracy: subjectStats, recentQuizzes, weeklyActivity });
  }

  async getLeaderboard(query: any, userId: string) {
    const { exam } = query;
    let userQuery = `SELECT id, name, avatar_url, primary_exam, streak, accuracy, rank, coins, total_study_minutes FROM users WHERE status='active' AND deleted_at IS NULL`;
    const params: any[] = [];
    if (exam) { userQuery += ` AND primary_exam=$1`; params.push(exam); }
    userQuery += ` ORDER BY rank ASC NULLS LAST, coins DESC LIMIT 100`;
    const [rows, myRank] = await Promise.all([
      this.db.query(userQuery, params),
      this.db.query(`SELECT rank, coins, streak, accuracy FROM users WHERE id=$1`, [userId]),
    ]);
    return successResponse({ leaderboard: rows, myRank: myRank[0] });
  }

  async getMyEnrollments(userId: string) {
    const rows = await this.db.query(
      `SELECT ue.*, c.title, c.instructor, c.thumbnail_url, c.total_lessons, c.subject, c.exam_tags
       FROM user_enrollments ue JOIN courses c ON ue.course_id=c.id
       WHERE ue.user_id=$1 ORDER BY ue.enrolled_at DESC`,
      [userId]
    );
    return successResponse({ enrollments: rows });
  }

  async getDownloads(userId: string) {
    const rows = await this.db.query(
      `SELECT ln.id, ln.title, ln.subject, ln.type, ln.file_url, ln.file_size_mb, ln.pages, nd.downloaded_at
       FROM note_downloads nd JOIN library_notes ln ON nd.note_id=ln.id
       WHERE nd.user_id=$1 ORDER BY nd.downloaded_at DESC`,
      [userId]
    );
    return successResponse({ downloads: rows });
  }

  async getCertificates(userId: string) {
    const rows = await this.db.query(
      `SELECT c.*, co.title AS course_title, co.subject
       FROM certificates c JOIN courses co ON c.course_id=co.id
       WHERE c.user_id=$1 ORDER BY c.issued_at DESC`,
      [userId]
    );
    return successResponse({ certificates: rows });
  }

  async getLiveClasses(userId: string) {
    const rows = await this.db.query(
      `SELECT lc.*, (SELECT TRUE FROM live_class_registrations WHERE live_class_id=lc.id AND user_id=$1) AS is_registered
       FROM live_classes lc WHERE lc.status!='cancelled' ORDER BY lc.scheduled_at ASC`,
      [userId]
    );
    return successResponse({ liveClasses: rows });
  }

  async registerLiveClass(classId: string, userId: string) {
    await this.db.query(`INSERT INTO live_class_registrations VALUES ($1,$2) ON CONFLICT DO NOTHING`, [classId, userId]);
    await this.db.query(`UPDATE live_classes SET registered_count=registered_count+1 WHERE id=$1`, [classId]);
    return successResponse(null, 'Registered for live class!');
  }

  async updateNotificationSettings(userId: string, enabled: boolean) {
    await this.db.query(`UPDATE users SET notification_enabled=$1, updated_at=NOW() WHERE id=$2`, [enabled, userId]);
    await this.cache.del(`user:${userId}`);
    return successResponse(null, 'Notification settings updated');
  }

  // Admin
  async getAdminLeaderboard() {
    const rows = await this.db.query(
      `SELECT id, name, primary_exam, streak, coins, accuracy, rank, total_study_minutes FROM users WHERE status='active' AND deleted_at IS NULL ORDER BY rank ASC NULLS LAST, coins DESC LIMIT 100`
    );
    return successResponse({ leaderboard: rows });
  }

  async recalculateRanks() {
    await this.db.query(
      `UPDATE users u SET rank=ranks.new_rank FROM (SELECT id, ROW_NUMBER() OVER (ORDER BY coins DESC, accuracy DESC, streak DESC) AS new_rank FROM users WHERE status='active' AND deleted_at IS NULL) ranks WHERE u.id=ranks.id`
    );
    return successResponse(null, 'Leaderboard recalculated ✅');
  }

  async getCertificatesAdmin(query: any) {
    const { page=1, limit=20 } = query;
    const offset = (page-1)*limit;
    const [rows, countResult] = await Promise.all([
      this.db.query(
        `SELECT c.*, u.name AS user_name, u.email, co.title AS course_title FROM certificates c JOIN users u ON c.user_id=u.id JOIN courses co ON c.course_id=co.id ORDER BY c.issued_at DESC LIMIT $1 OFFSET $2`,
        [limit, offset]
      ),
      this.db.query(`SELECT COUNT(*) FROM certificates`),
    ]);
    return successResponse({ certificates: rows }, 'Success', paginationMeta(parseInt(countResult[0].count), page, limit));
  }

  async getLiveClassesAdmin(query: any) {
    const rows = await this.db.query(
      `SELECT lc.*, (SELECT COUNT(*) FROM live_class_registrations WHERE live_class_id=lc.id) AS registered_count FROM live_classes lc ORDER BY lc.scheduled_at DESC`
    );
    return successResponse({ liveClasses: rows });
  }

  async createLiveClass(data: any, adminId: string) {
    if (!data.title || !data.scheduledAt) throw new BadRequestException('Title and scheduled time required');
    const result = await this.db.query(
      `INSERT INTO live_classes (title, instructor, subject, description, meeting_link, scheduled_at, duration_mins, exam_tags, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [data.title, data.instructor, data.subject, data.description, data.meetingLink, data.scheduledAt, data.durationMins||60, data.examTags||[], adminId]
    );
    return successResponse({ liveClass: result[0] }, 'Live class scheduled — visible in app ✅');
  }

  async updateLiveClass(classId: string, data: any) {
    const fields: string[] = [], vals: any[] = [];
    let i = 1;
    const map: any = { title:'title', instructor:'instructor', scheduledAt:'scheduled_at', durationMins:'duration_mins', status:'status', meetingLink:'meeting_link' };
    for (const [key, col] of Object.entries(map)) {
      if (data[key] !== undefined) { fields.push(`${col}=$${i++}`); vals.push(data[key]); }
    }
    if (fields.length) { fields.push('updated_at=NOW()'); await this.db.query(`UPDATE live_classes SET ${fields.join(',')} WHERE id=$${i}`, [...vals, classId]); }
    return successResponse(null, 'Live class updated ✅');
  }
}

@ApiTags('Users') @ApiBearerAuth() @UseGuards(JwtAuthGuard) @Controller('users')
class UsersController {
  constructor(private s: UsersService) {}
  @Get('profile')     getProfile(@Req() r: any) { return this.s.getProfile(r.user.id); }
  @Put('profile')     updateProfile(@Req() r: any, @Body() dto: any) { return this.s.updateProfile(r.user.id, dto); }
  @Put('exam-target') updateExamTarget(@Req() r: any, @Body() dto: any) { return this.s.updateExamTarget(r.user.id, dto); }
  @Get('stats')       getStats(@Req() r: any) { return this.s.getStats(r.user.id); }
  @Get('leaderboard') getLeaderboard(@Query() q: any, @Req() r: any) { return this.s.getLeaderboard(q, r.user.id); }
  @Get('enrollments') getEnrollments(@Req() r: any) { return this.s.getMyEnrollments(r.user.id); }
  @Get('downloads')   getDownloads(@Req() r: any) { return this.s.getDownloads(r.user.id); }
  @Get('certificates') getCertificates(@Req() r: any) { return this.s.getCertificates(r.user.id); }
  @Get('live-classes') getLiveClasses(@Req() r: any) { return this.s.getLiveClasses(r.user.id); }
  @Post('live-classes/:id/register') @HttpCode(200) registerLiveClass(@Param('id', ParseUUIDPipe) id: string, @Req() r: any) { return this.s.registerLiveClass(id, r.user.id); }
  @Put('notification-settings') updateNotifSettings(@Req() r: any, @Body() b: any) { return this.s.updateNotificationSettings(r.user.id, b.enabled); }
}

@ApiTags('Admin — Leaderboard & Live') @ApiBearerAuth() @Public()
@UseGuards(AdminJwtGuard, PermissionGuard) @Controller('admin')
class AdminUsersExtraController {
  constructor(private s: UsersService) {}
  @Get('leaderboard')           @RequirePermission('leaderboard') getLeaderboard()    { return this.s.getAdminLeaderboard(); }
  @Post('leaderboard/recalculate') @RequirePermission('leaderboard') recalculate()  { return this.s.recalculateRanks(); }
  @Get('certificates')          @RequirePermission('certificates') getCerts(@Query() q: any) { return this.s.getCertificatesAdmin(q); }
  @Get('live-classes')          @RequirePermission('live-classes') getLiveClasses(@Query() q: any) { return this.s.getLiveClassesAdmin(q); }
  @Post('live-classes')         @RequirePermission('live-classes') @HttpCode(201) createLiveClass(@Body() dto: any, @Req() r: any) { return this.s.createLiveClass(dto, r.admin.id); }
  @Put('live-classes/:id')      @RequirePermission('live-classes') updateLiveClass(@Param('id', ParseUUIDPipe) id: string, @Body() dto: any) { return this.s.updateLiveClass(id, dto); }
}

@Module({ controllers:[UsersController, AdminUsersExtraController], providers:[UsersService], exports:[UsersService] })
export class UsersModule {}

// ════════════════════════════════════════════════════════════
// BANNERS MODULE
// ════════════════════════════════════════════════════════════
@Injectable()
class BannersService {
  constructor(
    @InjectDataSource() private readonly db: DataSource,
    @Inject(CACHE_MANAGER) private readonly cache: Cache,
  ) {}

  async getActiveBanners(userExam?: string) {
    const cacheKey = `banners:${userExam||'all'}`;
    const cached   = await this.cache.get(cacheKey);
    if (cached) return cached;

    const rows = await this.db.query(
      `SELECT id, title, subtitle, image_url, action_link, type, bg_gradient, target
       FROM banners WHERE is_active=TRUE AND (target='all' OR target=$1)
       ORDER BY sort_order ASC, created_at DESC LIMIT 10`,
      [userExam || 'all']
    );
    const result = successResponse({ banners: rows });
    await this.cache.set(cacheKey, result, 120);
    return result;
  }

  async findAllAdmin() {
    const rows = await this.db.query(`SELECT * FROM banners ORDER BY sort_order, created_at DESC`);
    return successResponse({ banners: rows });
  }

  async create(data: any, adminId: string) {
    const result = await this.db.query(
      `INSERT INTO banners (title, subtitle, image_url, action_link, type, target, bg_gradient, sort_order, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [data.title, data.subtitle, data.imageUrl, data.actionLink, data.type||'promotion', data.target||'all', data.bgGradient, data.sortOrder||0, adminId]
    );
    await this.invalidateCache();
    return successResponse({ banner: result[0] }, 'Banner created — live in app ✅');
  }

  async update(bannerId: string, data: any) {
    const fields: string[] = [], vals: any[] = [];
    let i = 1;
    const map: any = { title:'title', subtitle:'subtitle', isActive:'is_active', sortOrder:'sort_order', actionLink:'action_link', imageUrl:'image_url' };
    for (const [key, col] of Object.entries(map)) {
      if (data[key] !== undefined) { fields.push(`${col}=$${i++}`); vals.push(data[key]); }
    }
    if (fields.length) { fields.push('updated_at=NOW()'); await this.db.query(`UPDATE banners SET ${fields.join(',')} WHERE id=$${i}`, [...vals, bannerId]); }
    await this.invalidateCache();
    return successResponse(null, 'Banner updated ✅');
  }

  async remove(bannerId: string) {
    await this.db.query(`DELETE FROM banners WHERE id=$1`, [bannerId]);
    await this.invalidateCache();
    return successResponse(null, 'Banner deleted');
  }

  async trackImpression(bannerId: string) {
    await this.db.query(`UPDATE banners SET impression_count=impression_count+1 WHERE id=$1`, [bannerId]);
  }

  async trackClick(bannerId: string) {
    await this.db.query(`UPDATE banners SET click_count=click_count+1 WHERE id=$1`, [bannerId]);
  }

  private async invalidateCache() {
    // Delete all banner cache keys — in production use Redis SCAN
    const patterns = ['banners:all', 'banners:BPSC 70th CCE', 'banners:Bihar Police SI'];
    for (const key of patterns) await this.cache.del(key);
  }
}

@ApiTags('Banners') @ApiBearerAuth() @UseGuards(JwtAuthGuard) @Controller('banners')
class BannersController {
  constructor(private s: BannersService) {}
  @Get()                    getBanners(@Req() r: any) { return this.s.getActiveBanners(r.user?.primary_exam); }
  @Post(':id/impression')   @HttpCode(200) impression(@Param('id', ParseUUIDPipe) id: string) { this.s.trackImpression(id); return { success: true }; }
  @Post(':id/click')        @HttpCode(200) click(@Param('id', ParseUUIDPipe) id: string) { this.s.trackClick(id); return { success: true }; }
}

@ApiTags('Admin — Banners') @ApiBearerAuth() @Public()
@UseGuards(AdminJwtGuard, PermissionGuard) @Controller('admin/banners')
class AdminBannersController {
  constructor(private s: BannersService) {}
  @Get()         @RequirePermission('banners') findAll()   { return this.s.findAllAdmin(); }
  @Post()        @RequirePermission('banners') @HttpCode(201) create(@Body() dto: any, @Req() r: any) { return this.s.create(dto, r.admin.id); }
  @Put(':id')    @RequirePermission('banners') update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: any) { return this.s.update(id, dto); }
  @Delete(':id') @RequirePermission('banners') remove(@Param('id', ParseUUIDPipe) id: string) { return this.s.remove(id); }
}

@Module({ imports:[ConfigModule], controllers:[BannersController, AdminBannersController], providers:[BannersService] })
export class BannersModule {}

// ════════════════════════════════════════════════════════════
// EXAMS MODULE
// ════════════════════════════════════════════════════════════
@Injectable()
class ExamsService {
  constructor(
    @InjectDataSource() private readonly db: DataSource,
    @Inject(CACHE_MANAGER) private readonly cache: Cache,
  ) {}

  async findAll() {
    const cacheKey = 'exams:active';
    const cached   = await this.cache.get(cacheKey);
    if (cached) return cached;

    const rows = await this.db.query(`SELECT * FROM exams WHERE is_active=TRUE ORDER BY sort_order, name`);
    const result = successResponse({ exams: rows });
    await this.cache.set(cacheKey, result, 600); // 10 min — exams change rarely
    return result;
  }

  async findAllAdmin() {
    const rows = await this.db.query(
      `SELECT e.*,
         COUNT(u.id) FILTER (WHERE u.primary_exam=e.name) AS total_users,
         COUNT(u.id) FILTER (WHERE u.primary_exam=e.name AND u.last_active_at>NOW()-INTERVAL '7 days') AS active_users
       FROM exams e LEFT JOIN users u ON u.primary_exam=e.name AND u.status='active' AND u.deleted_at IS NULL
       GROUP BY e.id ORDER BY e.sort_order, e.name`
    );
    return successResponse({ exams: rows });
  }

  async create(data: any) {
    if (!data.name || !data.fullName || !data.category) throw new BadRequestException('Name, fullName, category required');
    const result = await this.db.query(
      `INSERT INTO exams (name, full_name, category, emoji, sort_order) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [data.name, data.fullName, data.category, data.emoji||'🎯', data.sortOrder||0]
    );
    await this.cache.del('exams:active');
    return successResponse({ exam: result[0] }, 'Exam added — visible in app ✅');
  }

  async update(examId: string, data: any) {
    const fields: string[] = [], vals: any[] = [];
    let i = 1;
    const map: any = { name:'name', fullName:'full_name', category:'category', emoji:'emoji', isActive:'is_active', sortOrder:'sort_order' };
    for (const [key, col] of Object.entries(map)) {
      if (data[key] !== undefined) { fields.push(`${col}=$${i++}`); vals.push(data[key]); }
    }
    if (fields.length) { fields.push('updated_at=NOW()'); await this.db.query(`UPDATE exams SET ${fields.join(',')} WHERE id=$${i}`, [...vals, examId]); }
    await this.cache.del('exams:active');
    return successResponse(null, 'Exam updated ✅');
  }
}

@ApiTags('Exams') @Public() @Controller('exams')
class ExamsController {
  constructor(private s: ExamsService) {}
  @Get() findAll() { return this.s.findAll(); }
}

@ApiTags('Admin — Exams') @ApiBearerAuth() @Public()
@UseGuards(AdminJwtGuard, PermissionGuard) @Controller('admin/exams')
class AdminExamsController {
  constructor(private s: ExamsService) {}
  @Get()      @RequirePermission('dashboard') findAll()  { return this.s.findAllAdmin(); }
  @Post()     @RequirePermission('settings')  @HttpCode(201) create(@Body() dto: any) { return this.s.create(dto); }
  @Put(':id') @RequirePermission('settings')  update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: any) { return this.s.update(id, dto); }
}

@Module({ imports:[ConfigModule], controllers:[ExamsController, AdminExamsController], providers:[ExamsService] })
export class ExamsModule {}
