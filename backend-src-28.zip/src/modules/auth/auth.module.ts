// ════════════════════════════════════════════════════════════
// AUTH MODULE — Full implementation
// ════════════════════════════════════════════════════════════
import {
  Module, Injectable, Controller, Post, Get, Body, Req,
  HttpCode, HttpStatus, UnauthorizedException, BadRequestException,
  ConflictException,
  Patch,
  Delete,
} from '@nestjs/common';
import { InjectRepository, TypeOrmModule } from '@nestjs/typeorm';
import { Repository, LessThan, MoreThan } from 'typeorm';
import { JwtModule, JwtService } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { Inject } from '@nestjs/common';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import * as bcrypt from 'bcryptjs';
import * as axios from 'axios';
import {
  IsString, IsOptional, IsEmail, Length, Matches,
  IsNotEmpty,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';

import { JwtAuthGuard, Public } from '../../common/guards';
import { UseGuards, Request } from '@nestjs/common';
import { successResponse } from '../../common/utils/response.util';

// ── DTOs ──────────────────────────────────────────────────────
class SendOtpDto {
  @ApiProperty({ example: '+919876543210' })
  @IsString()
  @Matches(/^\+?91[6-9]\d{9}$/, { message: 'Invalid Indian mobile number' })
  mobile: string;
}

class VerifyOtpDto {
  @ApiProperty({ example: '+919876543210' })
  @IsString()
  mobile: string;

  @ApiProperty({ example: '123456' })
  @IsString()
  @Length(6, 6, { message: 'OTP must be 6 digits' })
  otp: string;
}

class RegisterDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  tempToken: string;

  @ApiProperty({ example: 'Rahul Kumar' })
  @IsString()
  @Length(2, 100)
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEmail()
  email?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  district?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  referralCode?: string;
}

class ExamSelectionDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  primaryExam: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  secondaryExam?: string;

  @ApiPropertyOptional({ enum: ['beginner','intermediate','advanced'] })
  @IsOptional()
  @IsString()
  prepLevel?: string;

  @ApiPropertyOptional()
  @IsOptional()
  targetYear?: number;
}

class RefreshTokenDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  refreshToken: string;
}

class FcmTokenDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  fcmToken: string;
}

// ── OTP Service ───────────────────────────────────────────────
@Injectable()
export class OtpService {
  constructor(
    @InjectDataSource() private readonly db: DataSource,
    private readonly config: ConfigService,
  ) {}

  async send(mobile: string): Promise<{ success: boolean; otp?: string }> {
    const otpConfig = this.config.get('otp');
    const otp       = this.generateOtp();
    const expiryMins = otpConfig.expiryMinutes;

    // Invalidate previous OTPs for this mobile
    await this.db.query(`DELETE FROM otps WHERE mobile = $1 AND is_used = FALSE`, [mobile]);

    // Store hashed OTP
    const hash = await bcrypt.hash(otp, 6);
    await this.db.query(
      `INSERT INTO otps (mobile, otp_hash, expires_at) VALUES ($1, $2, NOW() + $3::INTERVAL)`,
      [mobile, hash, `${expiryMins} minutes`]
    );

    if (this.config.get('app.env') === 'development') {
      console.log(`📱 DEV OTP for ${mobile}: ${otp}`);
      return { success: true, otp };
    }

    try {
      // await axios.default.post(
      //   'https://api.msg91.com/api/v5/otp',
      //   null,
      //   {
      //     params: {
      //       authkey: otpConfig.msg91AuthKey,
      //       mobile: `91${mobile.replace('+91', '')}`,
      //       template_id: otpConfig.msg91TemplateId,
      //       otp,
      //     },
      //   }
      // );

      console.log("OTP is __ : ", otp); 
return { success: true, otp };
    } catch (err) {
      console.error('MSG91 FULL ERROR:', err.response?.data || err.message);
      throw new BadRequestException('Failed to send OTP');
    }
  }

  async verify(mobile: string, otp: string): Promise<void> {
    const otpConfig = this.config.get('otp');
    const result = await this.db.query(
      `SELECT id, otp_hash, expires_at, attempts FROM otps WHERE mobile = $1 AND is_used = FALSE ORDER BY created_at DESC LIMIT 1`,
      [mobile]
    );
    if (!result.length) throw new BadRequestException('OTP not found or already used');

    const record = result[0];
    if (new Date() > new Date(record.expires_at)) {
      await this.db.query(`DELETE FROM otps WHERE id = $1`, [record.id]);
      throw new BadRequestException('OTP has expired. Please request a new one.');
    }
    if (record.attempts >= otpConfig.maxAttempts) {
      await this.db.query(`DELETE FROM otps WHERE id = $1`, [record.id]);
      throw new BadRequestException('Too many wrong attempts. Please request a new OTP.');
    }

    const isValid = await bcrypt.compare(otp, record.otp_hash);
    if (!isValid) {
      await this.db.query(`UPDATE otps SET attempts = attempts + 1 WHERE id = $1`, [record.id]);
      const remaining = otpConfig.maxAttempts - (record.attempts + 1);
      throw new BadRequestException(`Incorrect OTP. ${remaining} attempt(s) remaining.`);
    }

    await this.db.query(`UPDATE otps SET is_used = TRUE WHERE id = $1`, [record.id]);
  }

  private generateOtp(): string {
    // return Math.floor(100000 + Math.random() * 900000).toString();
    return "123456"
  }
}

// ── Auth Service ──────────────────────────────────────────────
@Injectable()
export class AuthService {
  constructor(
    @InjectDataSource() private readonly db: DataSource,
    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
    private readonly otpService: OtpService,
    @Inject(CACHE_MANAGER) private readonly cache: Cache,
  ) {
  }
  private generateAdminToken(admin: any) {
    return this.jwtService.sign(
      { adminId: admin.id },
      {
        secret: this.config.get('jwt.adminSecret'),
        expiresIn: '1d',
      }
    )
  }

  async sendOtp(mobile: string) {
    const result = await this.db.query(
      `SELECT id, name FROM users WHERE mobile = $1 AND deleted_at IS NULL`, [mobile]
    );
    const isNewUser = !result.length;
    const resp = await this.otpService.send(mobile);
    return { isNewUser, ...(resp.otp && { otp: resp.otp }) };
  }

  async verifyOtp(mobile: string, otp: string) {
    await this.otpService.verify(mobile, otp);

    const result = await this.db.query(
      `SELECT id, name, email, mobile, role, status, coins, streak, primary_exam,
              prep_level, referral_code, is_verified
       FROM users WHERE mobile = $1 AND deleted_at IS NULL`, [mobile]
    );

    if (!result.length) {
      // New user — issue a short-lived registration token
      const tempToken = this.jwtService.sign(
        { mobile, verified: true, type: 'registration' },
        { secret: this.config.get('jwt.secret'), expiresIn: '30m' }
      );
      return { isNewUser: true, tempToken };
    }

    const user = result[0];
    if (user.status === 'banned') {
      throw new UnauthorizedException('Your account has been suspended. Contact support.');
    }

    const tokens = await this.generateTokens(user.id);
    await this.db.query(
      `UPDATE users SET refresh_token = $1, mobile_verified = TRUE, last_active_at = NOW() WHERE id = $2`,
      [tokens.refreshToken, user.id]
    );
    await this.awardCoins(user.id, 'daily_login');

    return {
      isNewUser: false,
      ...tokens,
      user: this.sanitizeUser(user),
    };
  }

  async register(dto: RegisterDto) {
    let decoded: any;
    try {
      decoded = this.jwtService.verify(dto.tempToken, {
        secret: this.config.get('jwt.secret')
      });
    } catch {
      throw new UnauthorizedException('Invalid or expired verification token');
    }
    if (decoded.type !== 'registration' || !decoded.verified) {
      throw new UnauthorizedException('Invalid registration token');
    }

    const mobile = decoded.mobile;
    const existing = await this.db.query(`SELECT id FROM users WHERE mobile = $1`, [mobile]);
    if (existing.length) throw new ConflictException('Mobile already registered. Please login.');

    const refCode = this.generateReferralCode(dto.name);
    let referrerId = null;

    if (dto.referralCode) {
      const ref = await this.db.query(`SELECT id FROM users WHERE referral_code = $1`, [dto.referralCode]);
      if (ref.length) referrerId = ref[0].id;
    }

    const newUser = await this.db.transaction(async (em) => {
      const result = await em.query(
        `INSERT INTO users (name, email, mobile, mobile_verified, district, referral_code, referred_by)
         VALUES ($1,$2,$3,TRUE,$4,$5,$6) RETURNING *`,
        [dto.name, dto.email || null, mobile, dto.district || null, refCode, referrerId]
      );
      return result[0];
    });

    const tokens = await this.generateTokens(newUser.id);
    await this.db.query(`UPDATE users SET refresh_token = $1 WHERE id = $2`, [tokens.refreshToken, newUser.id]);

    await this.awardCoins(newUser.id, 'daily_login');

    if (referrerId) {
      await this.awardCoins(referrerId, 'referral', newUser.id);
      const refBonus = parseInt(this.config.get('business.referralCoinsReferee'));
      await this.db.query(`UPDATE users SET coins = coins + $1 WHERE id = $2`, [refBonus, newUser.id]);
      const bal = (await this.db.query(`SELECT coins FROM users WHERE id=$1`, [newUser.id]))[0].coins;
      await this.db.query(
        `INSERT INTO coin_transactions (user_id, type, amount, description, action, balance) VALUES ($1,'earned',$2,'Referral signup bonus','referral_signup',$3)`,
        [newUser.id, refBonus, bal]
      );
    }

    return {
      ...tokens,
      user: {
        id: newUser.id, name: newUser.name, email: newUser.email,
        mobile: newUser.mobile, referralCode: newUser.referral_code,
        isNewUser: true, needsExamSelection: true,
      },
    };
  }

   // ── PATCH /users/profile ─────────────────────────────────────
  // Updates name, email, bio, district, state, target_year, prep_level.
  // Clears user cache so next getMe() returns fresh data.
  async updateProfile(userId: string, dto: {
    name?: string; email?: string; bio?: string;
    district?: string; state?: string; target_year?: number; prep_level?: string;
  }) {
    const sets: string[] = [];
    const vals: any[]    = [];
    let i = 1;

    if (dto.name?.trim())      { sets.push(`name=$${i++}`);        vals.push(dto.name.trim()); }
    if (dto.email !== undefined){ sets.push(`email=$${i++}`);       vals.push(dto.email?.trim() || null); }
    if (dto.bio   !== undefined){ sets.push(`bio=$${i++}`);         vals.push(dto.bio?.trim()   || null); }
    if (dto.district !== undefined){ sets.push(`district=$${i++}`); vals.push(dto.district?.trim() || null); }
    if (dto.state !== undefined){ sets.push(`state=$${i++}`);       vals.push(dto.state?.trim()   || null); }
    if (dto.target_year)        { sets.push(`target_year=$${i++}`); vals.push(dto.target_year); }
    if (dto.prep_level)         { sets.push(`prep_level=$${i++}`);  vals.push(dto.prep_level); }

    if (!sets.length) throw new BadRequestException('No fields to update');

    sets.push(`updated_at=NOW()`);
    vals.push(userId);

    await this.db.query(
      `UPDATE users SET ${sets.join(', ')} WHERE id=$${i} AND deleted_at IS NULL`,
      vals
    );

    // Invalidate user cache so next /auth/me returns updated data
    await this.cache.del(`user:${userId}`);
    await this.cache.del(`profile:${userId}`);

    // Return fresh user data
    const user = await this.getMe(userId);
    return successResponse({ user }, 'Profile updated successfully');
  }

  // ── DELETE /users/account ─────────────────────────────────────
  // Soft-delete: sets deleted_at so user cannot log in again.
  // Hard-deletes happen via a scheduled job after 30 days.
  async deleteAccount(userId: string) {
    await this.db.query(
      `UPDATE users SET deleted_at=NOW(), status='deleted', refresh_token=NULL WHERE id=$1`,
      [userId]
    );
    await this.cache.del(`user:${userId}`);
    return successResponse(null, 'Account deleted successfully');
  }


  async examSelection(userId: string, dto: ExamSelectionDto) {
    await this.db.query(
      `UPDATE users SET primary_exam=$1, secondary_exam=$2, prep_level=$3, target_year=$4, updated_at=NOW() WHERE id=$5`,
      [dto.primaryExam, dto.secondaryExam || null, dto.prepLevel || 'beginner', dto.targetYear || null, userId]
    );
    // Invalidate user cache
    await this.cache.del(`user:${userId}`);
  }

  async refreshToken(refreshToken: string) {
    let decoded: any;
    try {
      decoded = this.jwtService.verify(refreshToken, {
        secret: this.config.get('jwt.refreshSecret')
      });
    } catch {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }

    const result = await this.db.query(
      `SELECT id, status, refresh_token FROM users WHERE id = $1`, [decoded.userId]
    );
    if (!result.length || result[0].refresh_token !== refreshToken) {
      throw new UnauthorizedException('Refresh token not recognized');
    }
    if (result[0].status === 'banned') throw new UnauthorizedException('Account suspended');

    const tokens = await this.generateTokens(decoded.userId);
    await this.db.query(`UPDATE users SET refresh_token = $1 WHERE id = $2`, [tokens.refreshToken, decoded.userId]);
    return tokens;
  }

  async logout(userId: string) {
    await this.db.query(`UPDATE users SET refresh_token = NULL, fcm_token = NULL WHERE id = $1`, [userId]);
    await this.cache.del(`user:${userId}`);
  }

  async updateFcmToken(userId: string, fcmToken: string) {
    await this.db.query(`UPDATE users SET fcm_token = $1 WHERE id = $2`, [fcmToken, userId]);
  }

  async getMe(userId: string) {
    const cacheKey = `user:${userId}`;
    const cached = await this.cache.get(cacheKey);
    if (cached) return cached;

    const result = await this.db.query(
      `SELECT u.*,
         (SELECT COUNT(*) FROM subscriptions s WHERE s.user_id = u.id AND s.status = 'active' AND s.ends_at > NOW()) > 0 AS is_subscribed,
         (SELECT plan FROM subscriptions s WHERE s.user_id = u.id AND s.status = 'active' AND s.ends_at > NOW() LIMIT 1) AS current_plan,
         -- FIX: compute live rank so it's never null
         -- Uses ROW_NUMBER over active users sorted by coins+accuracy+streak
         (SELECT row_num FROM (
           SELECT id,
             ROW_NUMBER() OVER (
               ORDER BY coins DESC, CAST(accuracy AS FLOAT) DESC, streak DESC
             ) AS row_num
           FROM users
           WHERE status='active' AND deleted_at IS NULL
         ) ranked WHERE ranked.id = u.id) AS live_rank
       FROM users u WHERE u.id = $1 AND u.deleted_at IS NULL`,
      [userId]
    );
    if (!result.length) throw new UnauthorizedException('User not found');

    const user = result[0];
    delete user.password_hash;
    delete user.refresh_token;
    delete user.fcm_token;

    // Map live_rank → rank so Android always has a non-null rank
    if (user.live_rank != null && (user.rank == null || user.rank === 0)) {
      user.rank = parseInt(user.live_rank, 10);
    }
    delete user.live_rank;

    await this.cache.set(cacheKey, user, 60); // 60 sec TTL
    return user;
  }

  // ── Helpers ──────────────────────────────────────────────────
  private async generateTokens(userId: string) {
    const jwtConfig = this.config.get('jwt');
    const [accessToken, refreshToken] = await Promise.all([
      this.jwtService.signAsync(
        { userId },
        { secret: jwtConfig.secret, expiresIn: jwtConfig.expiresIn }
      ),
      this.jwtService.signAsync(
        { userId, type: 'refresh' },
        { secret: jwtConfig.refreshSecret, expiresIn: jwtConfig.refreshExpiresIn }
      ),
    ]);
    return { accessToken, refreshToken };
  }

  // ── COMPREHENSIVE COIN RULES (used when DB coin_rules table has no row) ──────
  // This covers EVERY action used across all modules so coins never silently return 0.
  // DB rows override these defaults (admin can tune via admin panel).
  private static readonly COIN_DEFAULTS: Record<string, { coins: number; maxPerDay: number }> = {
    // Quiz actions — each type has its own daily limit
    daily_quiz:         { coins: 10,  maxPerDay: 1  },  // 1 daily quiz per day
    mock_quiz:          { coins: 10,  maxPerDay: 3  },  // up to 3 mock tests per day
    topic_quiz:         { coins: 15,  maxPerDay: 5  },  // up to 5 topic quizzes per day
    quiz_attempt:       { coins: 10,  maxPerDay: 5  },  // legacy fallback
    // Study actions
    study_session:      { coins: 15,  maxPerDay: 1 },
    study_room:         { coins: 5,   maxPerDay: 2 },
    active_recall:      { coins: 5,   maxPerDay: 3 },
    // Content creation
    material_upload:    { coins: 25,  maxPerDay: 1 },
    // Auth / engagement
    daily_login:        { coins: 5,   maxPerDay: 1 },
    referral:           { coins: 75,  maxPerDay: 5 },
    profile_complete:   { coins: 20,  maxPerDay: 1 },
    // Ads
    ad_watch:           { coins: 5,   maxPerDay: 3 },
    watch_ad:           { coins: 5,   maxPerDay: 3 },  // alias
    // Achievements & leaderboard
    achievement:        { coins: 10,  maxPerDay: 10 },
    leaderboard_reward: { coins: 50,  maxPerDay: 1 },
    tier_promotion:     { coins: 20,  maxPerDay: 1 },
    weekly_challenge:   { coins: 30,  maxPerDay: 1 },
    // Streaks
    streak_7:           { coins: 15,  maxPerDay: 1 },
    streak_30:          { coins: 100, maxPerDay: 1 },
    mock_top10:         { coins: 100, maxPerDay: 1 },
    // Daily targets
    target_complete:    { coins: 1,   maxPerDay: 20 },
    // Subscriptions
    subscription_bonus: { coins: 0,   maxPerDay: 1 },
  };

  async awardCoins(userId: string, action: string, refId?: string, coinsOverride?: number): Promise<number> {
    try {
      // Try DB first — admin can override amounts via admin panel
      const dbRules = await this.db.query(
        `SELECT coins_awarded, max_per_day FROM coin_rules WHERE action = $1 AND is_active = TRUE`,
        [action]
      );

      const defaults = AuthService.COIN_DEFAULTS[action];

      // Use DB rule if present, otherwise fall back to code defaults
      // If neither exists, log a warning and return 0
      // FIX: Safe parsing — parseInt(null) or parseInt(undefined) = NaN which crashes Postgres
      // Always fall back to COIN_DEFAULTS when DB value is missing/null/NaN
      const dbCoins     = dbRules.length > 0 ? Number(dbRules[0].coins_awarded) : NaN;
      const dbMaxPerDay = dbRules.length > 0 ? Number(dbRules[0].max_per_day)   : NaN;

      // Priority: coinsOverride (per-quiz admin value) > DB rule > COIN_DEFAULTS
      const coinsToAward =
        (coinsOverride !== undefined && coinsOverride > 0) ? coinsOverride
        : (!isNaN(dbCoins) && dbCoins >= 0)               ? dbCoins
        : (defaults?.coins ?? -1);

      const maxPerDay = (!isNaN(dbMaxPerDay) && dbMaxPerDay > 0)
        ? dbMaxPerDay
        : (defaults?.maxPerDay ?? 1);

      if (coinsToAward <= 0 || isNaN(coinsToAward)) {
        console.warn(`awardCoins: no valid coins for action '${action}'`);
        return 0;
      }

      // Idempotency — respect daily cap
      const todayCount = await this.db.query(
        `SELECT COUNT(*) FROM coin_transactions
         WHERE user_id=$1 AND action=$2 AND created_at::date = CURRENT_DATE`,
        [userId, action]
      );
      if (parseInt(todayCount[0].count) >= maxPerDay) return 0;

      // Award coins — UPDATE first, then record transaction separately
      // IMPORTANT: return coinsToAward as soon as UPDATE succeeds.
      // A failed transaction INSERT must NOT cause return 0 — that leaves the
      // user with added coins but a response claiming coinsEarned=0.
      const balResult = await this.db.query(
        `UPDATE users
         SET coins = COALESCE(coins,0) + $1,
             total_coins_earned = COALESCE(total_coins_earned,0) + $1
         WHERE id = $2 RETURNING coins`,
        [coinsToAward, userId]
      );

      if (!balResult.length) return 0;
      const newBalance = Number(balResult[0].coins) || 0;

      // Record transaction — non-blocking: failure here must NOT roll back coins
      // or return 0. Fire and wait, but catch independently.
      try {
        // Validate refId is a proper UUID before inserting — non-UUID strings cause "invalid UUID" error
        const safeRefId = refId && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(refId)
          ? refId : null;
        await this.db.query(
          `INSERT INTO coin_transactions
             (user_id, type, amount, description, action, ref_id, balance)
           VALUES ($1,'earned',$2,$3,$4,$5,$6)`,
          [userId, coinsToAward, `${action} reward`, action, safeRefId, newBalance]
        );
      } catch (txErr: any) {
        // Log but do NOT rethrow — coins were already awarded, just missing the history row
        console.error(`coin_transactions INSERT failed for action=${action}:`, txErr.message);
        // Attempt a simpler INSERT without ref_id to at least record it
        this.db.query(
          `INSERT INTO coin_transactions (user_id, type, amount, description, action, balance)
           VALUES ($1,'earned',$2,$3,$4,$5)`,
          [userId, coinsToAward, `${action} reward`, action, newBalance]
        ).catch(() => {}); // truly non-blocking fallback
      }

      await this.cache.del(`user:${userId}`);
      return coinsToAward;

    } catch (err) {
      console.error('awardCoins error:', err.message);
      return 0;
    }
  }



  private sanitizeUser(user: any) {
    const { password_hash, refresh_token, fcm_token, ...safe } = user;
    return safe;
  }

  private generateReferralCode(name: string): string {
    const base = name.replace(/\s+/g, '').toUpperCase().slice(0, 6);
    const num  = Math.floor(1000 + Math.random() * 9000);
    return `${base}${num}`;
  }
}

// ── JWT Strategy ──────────────────────────────────────────────
@Injectable()
export class UserJwtStrategy extends PassportStrategy(Strategy as any, 'jwt') {
  constructor(
    private readonly config: ConfigService,
    @InjectDataSource() private readonly db: DataSource,
  ) {
    super({
      jwtFromRequest:   ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey:      config.get('jwt.secret'),
    });
  }

  async validate(payload: any) {
    const result = await this.db.query(
      `SELECT id, name, email, mobile, role, status, coins, primary_exam, prep_level, is_verified, notification_enabled
       FROM users WHERE id = $1 AND deleted_at IS NULL`,
      [payload.userId]
    );
    if (!result.length) throw new UnauthorizedException();
    const user = result[0];
    if (user.status === 'banned') throw new UnauthorizedException('Account suspended');

    // Update last_active async (fire-and-forget)
    this.db.query(`UPDATE users SET last_active_at = NOW() WHERE id = $1`, [user.id]).catch(() => {});

    console.log("ADMIN PAYLOAD:", payload);

    return user;
    // return user;
  }
}

// ── Admin JWT Strategy ────────────────────────────────────────
@Injectable()
export class AdminJwtStrategy extends PassportStrategy(Strategy as any, 'admin-jwt') {
  constructor(
    private readonly config: ConfigService,
    @InjectDataSource() private readonly db: DataSource,
  ) {
    super({
      jwtFromRequest:   ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey:      config.get('jwt.adminSecret'),
    });
  }

  async validate(payload: any) {
    const result = await this.db.query(
      `SELECT id, name, email, permissions, status FROM admin_users WHERE id = $1`,
      [payload.adminId]
    );
    if (!result.length) throw new UnauthorizedException();
    return result[0];
  }
}

// ── Auth Controller ───────────────────────────────────────────
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Public()
  @Post('send-otp')
  @HttpCode(HttpStatus.OK)
  @Throttle({ default: { limit: 30, ttl: 900000 } })
  async sendOtp(@Body() dto: SendOtpDto) {
    const data = await this.authService.sendOtp(dto.mobile);
    return successResponse(data, `OTP sent to ${dto.mobile}`);
  }

  @Public()
  @Post('verify-otp')
  @HttpCode(HttpStatus.OK)
  async verifyOtp(@Body() dto: VerifyOtpDto) {
    const data = await this.authService.verifyOtp(dto.mobile, dto.otp);
    const msg  = data.isNewUser ? 'OTP verified. Please complete registration.' : 'Login successful';
    return successResponse(data, msg);
  }

  @Public()
  @Post('register')
  @HttpCode(HttpStatus.CREATED)
  async register(@Body() dto: RegisterDto) {
    const data = await this.authService.register(dto);
    return successResponse(data, 'Registration successful! Welcome to BPSCNotes 🎉');
  }

  @Post('exam-selection')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async examSelection(@Req() req: any, @Body() dto: ExamSelectionDto) {
    await this.authService.examSelection(req.user.id, dto);
    return successResponse(null, "Let's start preparing! 🚀");
  }

  @Public()
  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  async refresh(@Body() dto: RefreshTokenDto) {
    const tokens = await this.authService.refreshToken(dto.refreshToken);
    return successResponse(tokens, 'Token refreshed');
  }

  @Post('logout')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async logout(@Req() req: any) {
    await this.authService.logout(req.user.id);
    return successResponse(null, 'Logged out successfully');
  }

  @Post('fcm-token')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async updateFcmToken(@Req() req: any, @Body() dto: FcmTokenDto) {
    await this.authService.updateFcmToken(req.user.id, dto.fcmToken);
    return successResponse(null, 'Device registered for notifications');
  }

  @Get('me')
  @UseGuards(JwtAuthGuard)
  async getMe(@Req() req: any) {
    const user = await this.authService.getMe(req.user.id);
    return successResponse({ user });
  }


 // ── PATCH /users/profile ─────────────────────────────────────
 @Patch('users/profile')
 @UseGuards(JwtAuthGuard)
 @HttpCode(HttpStatus.OK)
 async updateProfile(@Req() req: any, @Body() dto: any) {
   return this.authService.updateProfile(req.user.id, dto);
 }

 // ── DELETE /users/account ────────────────────────────────────
 @Delete('users/account')
 @UseGuards(JwtAuthGuard)
 @HttpCode(HttpStatus.OK)
 async deleteAccount(@Req() req: any) {
   return this.authService.deleteAccount(req.user.id);
 }

 // ── POST /auth/logout ────────────────────────────────────────
 // Already has logout() but adding alias for /auth/logout path
}

// ── Auth Module ───────────────────────────────────────────────
@Module({
  imports: [
   // PassportModule.register({ defaultStrategy: 'jwt' }),
    JwtModule.registerAsync({
      imports:    [ConfigModule],
      inject:     [ConfigService],
      useFactory: (config: ConfigService) => ({
        secret:     config.get('jwt.secret'),
        signOptions: { expiresIn: config.get('jwt.expiresIn') },
      }),
    }),
  ],
  controllers: [AuthController],
  providers:   [AuthService, OtpService, UserJwtStrategy, AdminJwtStrategy],
  exports:     [AuthService, UserJwtStrategy, AdminJwtStrategy],
})
export class AuthModule {}